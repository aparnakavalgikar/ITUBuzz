package com.itubuzz.valueobjects;

public class SearchVO {
	
		public int search_id;
		public String search_value;
		
		public int getSearch_id() {
			return search_id;
		}
		
		public void setSearch_id(int search_id) {
			this.search_id = search_id;
		}
		
		public String getSearch_value() {
			return search_value;
		}
		
		public void setSearch_value(String search_value) {
			this.search_value = search_value;
		}
}
