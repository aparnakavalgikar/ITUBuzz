package com.itubuzz.valueobjects;

public class ReplyVO {
  
	public int reply_id;
	public String reply_text;
	public int reply_user_id;
	public int reply_post_id;
	
	public int getReply_id() {
		return reply_id;
	}
	public void setReply_id(int reply_id) {
		this.reply_id = reply_id;
	}
	public String getReply_text() {
		return reply_text;
	}
	public void setReply_text(String reply_text) {
		this.reply_text = reply_text;
	}
	public int getReply_user_id() {
		return reply_user_id;
	}
	public void setReply_user_id(int reply_user_id) {
		this.reply_user_id = reply_user_id;
	}
	public int getReply_post_id() {
		return reply_post_id;
	}
	public void setReply_post_id(int reply_post_id) {
		this.reply_post_id = reply_post_id;
	}
	
	
	
}
