package com.itubuzz.webapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itubuzz.dao.*;
import com.itubuzz.valueobjects.*;

/**
 * Servlet implementation class ReplyDataServlet
 */
public class ReplyDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ArrayList<ReplyVO> complete_reply_data;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReplyDataServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		HttpSession session = request.getSession(false); 
		String reply_value = request.getParameter("reply_text");
		System.out.println("value from jsp is : "+ request.getParameter("reply_user_id"));
		System.out.println("value from jsp is : "+ request.getParameter("reply_post_id"));
		String reply_user_id = request.getParameter("reply_user_id"); 
		String reply_post_id = request.getParameter("reply_post_id");
		
		System.out.println("user id passed is in reply data servlet:"+reply_user_id);
		System.out.println("post id passed is in reply data servlet:"+reply_post_id);
		System.out.println(reply_value);
		
		if(reply_value.length()>0){
			if(ReplyDAO.replydataCred(reply_value,reply_user_id,reply_post_id)){ 
				 complete_reply_data = new ArrayList<ReplyVO>();
			     complete_reply_data = RetrieveReplyDAO.retrieveRepliedData(reply_post_id, reply_user_id);
				 session.setAttribute("post_updated_value", complete_reply_data);
				 RequestDispatcher rd=request.getRequestDispatcher("HomePage.jsp");      
		         rd.forward(request,response); 
	             }    
			}
			else{
  	    	  session.invalidate();
                 request.setAttribute("errorMessage", "Please type a reply");
                 RequestDispatcher rd = request.getRequestDispatcher("HomePage.jsp");
                 rd.forward(request, response);
  	          }
		
		out.close(); 
	}
		
}