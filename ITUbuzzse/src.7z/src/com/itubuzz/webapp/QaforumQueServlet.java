package com.itubuzz.webapp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.itubuzz.dao.*;
import com.itubuzz.valueobjects.*;

/**
 * Servlet implementation class QaforumQueServlet
 */
public class QaforumQueServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private QuestionVO question_data = new QuestionVO();
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QaforumQueServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean question = false;
		String question_text = null;
		response.setContentType("text/html"); 
		PrintWriter out = response.getWriter(); 
		HttpSession session = request.getSession(false); 
		question_text = request.getParameter("question_text");
		String user_id = request.getParameter("log_user_id");
		
		if ( question_text.endsWith("?") ){ 
			String[] qkeywords = {"WHAT", "WHERE", "WHY", "WHICH", "WHO", "WHOSE", "HOW", "WHEN"};
			for (int i=0; i<qkeywords.length; i++)
				if(question_text.toUpperCase().contains(qkeywords[i])) {					
					question = true;
				}
		}
		if (question) {
			if(question_text.length()>0){
						if(QaforumDAO.forumdataCred(question_text,user_id)){ 
							 question_data = RetrieveQaforumDAO.retrieveQueData(question_text);
							 session.setAttribute("question_data", question_data);
							 RequestDispatcher rd=request.getRequestDispatcher("QuestionPage.jsp");      
					         rd.forward(request,response);
				             }    
						}
		} else {
  	    	  session.invalidate();
                 request.setAttribute("errorMessage", "Please type a question");
                 RequestDispatcher rd = request.getRequestDispatcher("QAforum.jsp");
                 rd.forward(request, response);
  	          }
		
		out.close(); 
	}
}